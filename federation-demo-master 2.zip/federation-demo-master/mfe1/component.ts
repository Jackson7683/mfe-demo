import * as rxjs from 'rxjs';
const styleText = require('!raw-loader!./styles.css');

// below are using web components
const template = document.createElement('templ');
template.innerHTML = `
    <style>${styleText.default}</style>
    <div id="container">
        <h1>Card</h1>
        <div class="fields">
            <div>
                <input type="text" id="name" placeholder="name">
            </div>
            <div>
                <input type="text" id="email" placeholder="email">
            </div>
        </div>
        <div>
            <button id="toggle-btn"></button>
        </div>
    </div>
`;

class Microfrontend1 extends HTMLElement {

    showCard: boolean;
    fields: HTMLElement;
    name: HTMLInputElement;
    email: HTMLInputElement;
    btn: HTMLElement;
    
    // constructor is what instantiate the custom component
    constructor() {
        super();
        this.showCard = true;

        // use attachShadow method to attach shadow DOM for the web component
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.appendChild(template.cloneNode(true))

        // shadowRoot is the javascript object of shadow DOM <=> similar to 'document' 
        this.fields = this.shadowRoot.querySelector('.fields');
        this.name = this.shadowRoot.querySelector('#name');
        this.email = this.shadowRoot.querySelector('#email');
        this.btn = this.shadowRoot.getElementById('toggle-btn');

        // getAttribute is standard web component API to get value of given attribute
        this.name.value = this.getAttribute('name');
        this.email.value = this.getAttribute('email');      
        this.btn.innerText = 'Hide this info';  
    }

    async connectedCallback() {
        // const rxjs = await require('rxjs');
        // using rxjs.fromEvent() <=> btn.addEventListener('click', () => {}), except turning the event to observable
        rxjs.fromEvent(this.btn, 'click').subscribe(_ => this.toggle());
    }

    async disconnectCallback() {
        this.btn.removeEventListener('click', this.toggle);
    }

    toggle(){ 
        this.showCard = !this.showCard;

        if (this.showCard) {
            this.fields.style.display = 'block';
            this.btn.innerText = 'Hide this info'
        } else {
            this.fields.style.display = 'none';
            this.btn.innerText = 'Show this info'
        }
    }
}

const elementName = 'microfrontend-one';
customElements.define(elementName, Microfrontend1);

export { elementName };