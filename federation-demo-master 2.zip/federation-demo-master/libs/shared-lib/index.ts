var _data = '';

export function setData(data: string): void {
    _data = data;
}

export function getData(): string {
    return _data;
}