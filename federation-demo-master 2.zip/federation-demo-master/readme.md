# Sharing local Libs

- Start
  - npm run serve:shell
  - npm run serve:mfe1

- Shared-Lib
  - Shared in both webpack configs
  - Mappings in tsconfig.json

- Test
  - After loading mfe1 into the shell (2nd menu item), mfe1 should display "Hello from the Shell".

